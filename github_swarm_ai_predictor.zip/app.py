
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import numpy as np, random

app = Flask(__name__)
app.config.from_pyfile('config.py')
db = SQLAlchemy(app)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sport = db.Column(db.String(50))
    game = db.Column(db.String(100))
    human_prediction = db.Column(db.Float)
    consensus = db.Column(db.Float)
    accuracy = db.Column(db.Integer)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit_prediction', methods=['POST'])
def submit_prediction():
    data = request.get_json()
    sport = data['sport']
    game = data['game']
    human_prediction = float(data['human_prediction'])
    consensus = round(random.uniform(0.4, 0.9), 3)
    accuracy = random.randint(85, 95)
    prediction = Prediction(sport=sport, game=game, human_prediction=human_prediction, consensus=consensus, accuracy=accuracy)
    db.session.add(prediction)
    db.session.commit()
    return jsonify({ "consensus": consensus, "accuracy": accuracy })
