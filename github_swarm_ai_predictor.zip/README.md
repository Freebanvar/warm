# Swarm AI Predictor

[![Render Deploy](https://img.shields.io/badge/Deployed-Render-green)](https://render.com)

A Flask-based sports prediction tool using Swarm AI simulation.

## Features

- Agent-based simulation of group prediction
- Round-by-round convergence charts
- Export and chart download
- Configurable swarm size and rounds

## Deploy

1. Fork and clone
2. Push to GitHub
3. Deploy via [Render.com](https://render.com)

## Start Locally

```bash
pip install -r requirements.txt
python app.py
```
